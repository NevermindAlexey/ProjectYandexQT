# -*- coding: utf-8 -*-
"""
Created on Mon Dec  7 17:43:31 2020

@author: Максим
"""
import sqlite3

con = sqlite3.connect(input() + ".sqlite")
cur = con.cursor()
result = cur.execute("""SELECT title FROM films
            WHERE year >= ? and genre = ?"""), (1997, (
            """SELECT id FROM genres WHERE title = 'музыка' OR 'анимация'""")).fetchall()
for elem in result:
    print(*elem)
con.close()
