# -*- coding: utf-8 -*-
"""
Created on Sun Nov 22 20:36:25 2020

@author: Максим
"""

import sys
import csv
from random import randrange as rand
from PyQt5 import QtWidgets
import qtprojectinterface


with open("locations.csv", encoding="utf8") as file:
    reader = csv.DictReader(file, delimiter=';', quotechar='"')
    loc_quotes = sorted(reader, key=lambda x: int(x['level']))

print(loc_quotes[0]['text'])


class RPGgame(QtWidgets.QMainWindow, qtprojectinterface.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.attack.clicked.connect(self.buttons_reactions)
        self.trade.clicked.connect(self.buttons_reactions)
        self.run.clicked.connect(self.buttons_reactions)
        self.nextturn.clicked.connect(self.buttons_reactions)
        self.findbattle.clicked.connect(self.buttons_reactions)
        self.findtown.clicked.connect(self.buttons_reactions)
        self.inventory.clicked.connect(self.buttons_reactions)
        self.usesnack1.clicked.connect(self.buttons_reactions)
        self.usesnack2.clicked.connect(self.buttons_reactions)
        self.check.clicked.connect(self.buttons_reactions)
        self.work.clicked.connect(self.buttons_reactions)
        self.nextenemy.clicked.connect(self.buttons_reactions)
        self.your_hp = 20
        self.your_en = 100
        self.your_money = 10
        self.lvl = 1
        self.xp = 0
        self.max_xp = 100
        self.curr_loc = "forest"
        self.current_turn = 0
        self.full_logs = ""
        self.end = 0
        self.player_hp.display(self.your_hp)
        self.player_en.display(self.your_en)
        self.money.display(self.your_money)
        self.snacks1 = 0
        self.snacks2 = 0
        self.work_hours_turn = 0
        self.xpbar.setValue(self.xp)
        self.ensnack.display(self.snacks2)
        self.hpsnack.display(self.snacks1)
        self.you_have = [0, 0, 0] 
    
    def buttons_reactions(self):
        c = self.sender()
        if c == self.nextturn:
            self.current_turn += 1
            if self.lvl == 1:
                self.loc_quote_code = rand(9)
            self.full_logs += "\n" + loc_quotes[self.loc_quote_code]['text'] + "\n"
            self.logs.setText(self.full_logs)
        elif c == self.attack:
            print("a")
        elif c == self.trade:
            print("-10 money")
        elif c == self.run:
            print("why are you running")
        elif c == self.findbattle:
            print("bonk")
        elif c == self.findtown:
            print("no")
        elif c == self.inventory:
            self.full_logs += ("\n" + "У Вас есть: "  + str(self.you_have[0]) + " дерева, " +
                               str(self.you_have[1]) + " камня, " + str(self.you_have[2]) +
                               " кристаллов." + "\n")
            self.logs.setText(self.full_logs)
        elif c == self.usesnack1:
            if self.snacks1 == 0:
                self.full_logs += "\n" + "У вас нет HP батончиков" + "\n"
                self.logs.setText(self.full_logs)
        elif c == self.usesnack2:
            if self.snacks2 == 0:
                self.full_logs += "\n" + "У вас нет EN батончиков" + "\n"
                self.logs.setText(self.full_logs)
        elif c == self.check:
            print("all clear")
        elif c == self.work:
            if self.work_hours_turn >= 3:
                self.full_logs += "\n" + "Вы устали и не хотите работать" + "\n"
                self.logs.setText(self.full_logs)
            else:
                if self.lvl == 1:
                    self.you_have[0] += self.lvl
                elif self.lvl == 2:
                    self.you_have[0] += self.lvl
                    self.you_have[1] += self.lvl
                elif self.lvl == 3:
                    self.you_have[0] += self.lvl
                    self.you_have[1] += self.lvl
                    self.you_have[2] += self.lvl
            self.work_hours_turn += 1
        elif c == self.nextenemy:
            print("what enemy")
        if self.xp == self.max_xp:
            self.lvl += 1
            self.xp = 0
            self.max_xp += 50
            self.xpbar.maxValue(self.max_xp)


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    game = RPGgame()
    game.show()
    sys.exit(app.exec())
